import {
  Controller,
  Get,
  Post,
  Body,
  UseGuards,
  HttpException,
} from '@nestjs/common';

import { AuthService } from './auth.service';
import { Resource } from '../keycloak/decorators/resource.decorator';
import { AuthGuard } from '../keycloak/guards/auth.guard';
import { AllowAnyRole } from '../keycloak/decorators/allow-any-role.decorator';
import { Roles } from '../keycloak/decorators/roles.decorator';
import { Public } from '../keycloak/decorators/unprotected.decorator';

@Controller()
// @Resource('authresource')
export class AuthController {
  constructor(private authService: AuthService) {}

  // @UseGuards(AuthGuard)
  // @Public()
  @Roles('realm:demorole')
  // @Roles('democlientrole')
  // @AllowAnyRole()
  @Get('be')
  be() {
    return 'be priv8';
  }

  // @Public()
  // @UseGuards(AuthGuard)
  @Get('me')
  me() {
    return 'me priv8';
  }

  @Public()
  @Post('auth/login')
  async login(@Body() body) {
    const res = await this.authService.login(body.username, body.password);
    console.log(res);

    return res;
  }

  @Public()
  @Post('auth/refresh')
  async refresh(@Body() body) {
    const res = await this.authService.refresh(body.refresh_token);
    console.log(res);

    return res;
  }

  @Post('auth/logout')
  async logout(@Body() body) {
    const res = await this.authService.logout(body.refresh_token);
    console.log(res);

    return res;
  }
}
