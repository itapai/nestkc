import { APP_GUARD } from '@nestjs/core';
import { Module } from '@nestjs/common';

// import { PassportModule } from '@nestjs/passport';
// import { JwtModule } from '@nestjs/jwt';
// import { UsersModule } from '../users/users.module';
// import { KeycloakModule } from '../keycloak/keycloak.module';
// import { LocalStrategy } from './strategies/local.strategy';
// import { JwtStrategy } from './strategies/jwt.strategy';
// import { KeycloakStrategy } from './strategies/keycloak.strategy';

// import { jwtConstants } from './contants';

import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import {
  KeycloakModule,
  AuthGuard,
  ResourceGuard,
  RoleGuard,
} from '../keycloak/keycloak.module';

@Module({
  imports: [
    // UsersModule,
    KeycloakModule.register({
      authServerUrl: 'http://localhost:8080/auth',
      realm: 'demo',
      clientId: 'democlient',
      secret: 'd30b210b-2f56-4f0a-984c-f279e38aec63',
    }),
    // PassportModule,
    // JwtModule.register({
    //   secret: jwtConstants.secret,
    //   signOptions: { expiresIn: '59s' },
    // }),
  ],
  providers: [
    AuthService,
    // LocalStrategy,
    // JwtStrategy,
    // KeycloakStrategy,
    // These are in order, see https://docs.nestjs.com/guards#binding-guards
    // for more information

    // Will return a 401 unauthorized when it is unable to
    // verify the JWT token or Bearer header is missing.
    {
      provide: APP_GUARD,
      useClass: AuthGuard,
    },
    // This adds a global level resource guard, which is permissive.
    // Only controllers annotated with @Resource and methods with @Scopes
    // are handled by this guard.
    {
      provide: APP_GUARD,
      useClass: ResourceGuard,
    },
    // This adds a global level role guard, which is permissive.
    // Used by `@Roles` decorator with the optional `@AllowAnyRole` decorator for allowing any
    // specified role passed.
    {
      provide: APP_GUARD,
      useClass: RoleGuard,
    },
  ],
  controllers: [AuthController],
  exports: [AuthService],
})
export class AuthModule {}
