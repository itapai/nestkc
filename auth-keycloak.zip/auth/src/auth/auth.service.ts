import { Injectable } from '@nestjs/common';
import { KeycloakService } from '../keycloak/keycloak.service';

@Injectable()
export class AuthService {
  constructor(private keycloakService: KeycloakService) {}

  // Login with username/password
  // Returns access_token, refresh_token
  login(username: string, password: string) {
    return this.keycloakService.login(username, password);
  }

  // Use refresh_token to logout
  logout(refreshToken: string) {
    return this.keycloakService.logout(refreshToken);
  }

  // Refresh access_token with refresh_token
  refresh(token: string) {
    return this.keycloakService.refresh(token);
  }
}
