import { Injectable, UnauthorizedException } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
// import { Strategy } from 'passport-local';
import * as Strategy from 'passport-keycloak-oauth2-oidc';
// import * as Strategy from 'passport-keycloak-bearer';

import { AuthService } from '../auth.service';
import { KeycloakService } from '../../keycloak/keycloak.service';

@Injectable()
// export class KeycloakStrategy extends PassportStrategy(Strategy) {
export class KeycloakStrategy extends PassportStrategy(Strategy) {
  constructor(private keycloakService: KeycloakService) {
    // super(
    //   {
    //     realm: 'demo',
    //     url: 'http://localhost:8080/auth',
    //   },
    //   (jwtPayload, done) => {
    //     console.log(jwtPayload);
    //     return done(null, jwtPayload);
    //   },
    // );
    super(
      {
        clientID: 'democlient',
        realm: 'demo',
        publicClient: 'true',
        sslRequired: 'external',
        authServerURL: 'http://localhost:8080/auth',
        callbackURL: 'http://localhost:3000/callback',
      },
      (accessToken, refreshToken, profile, done) => {
        console.log(accessToken);
        done(accessToken);
      },
    );
  }

  // async validate(username: string, password: string): Promise<any> {
  //   const user = await this.authService.validateUser(username, password);
  //   if (!user) {
  //     throw new UnauthorizedException();
  //   }
  //   return user;
  // }
}

// var KeyCloakStrategy = require('passport-keycloak-oauth2-oidc').Strategy;
//   passport.use(new KeyCloakStrategy({
//       clientID: 'myOauthClient',
//       realm: 'MyKeyCloakRealm',
//       publicClient: 'false',
//       clientSecret: '6ee0f303-faef-42d7-ba8e-00cdec755c42',
//       sslRequired: 'external',
//       authServerURL: 'https://keycloak.example.com/auth',
//       callbackURL: 'https://www.example.com/keycloak/callback'
//     },
//     function(accessToken, refreshToken, profile, done) {
//       User.findOrCreate(..., function err, user) {
//         done(err, user);
//       });
//     }
//   });
//
