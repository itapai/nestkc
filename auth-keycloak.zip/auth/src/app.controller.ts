import {
  Controller,
  Request,
  Get,
  Post,
  UseGuards,
  Body,
  HttpException,
} from '@nestjs/common';

import { AuthService } from './auth/auth.service';
import { JwtAuthGuard } from './auth/guards/jwt-auth.guard';
import { KeycloakAuthGuard } from './auth/guards/keycloak.guard';
import { Roles } from './keycloak/decorators/roles.decorator';
import { Public } from './keycloak/decorators/unprotected.decorator';
import { AuthGuard } from './keycloak/guards/auth.guard';

@Controller()
export class AppController {}
