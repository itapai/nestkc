import { Injectable, Inject, Scope, HttpException } from '@nestjs/common';
import { Keycloak } from 'keycloak-connect';
import { KeycloakConnectOptions } from './interface/keycloak-connect-options.interface';
import { KEYCLOAK_CONNECT_OPTIONS, KEYCLOAK_INSTANCE } from './constants';
import fetch from 'node-fetch';

@Injectable({ scope: Scope.REQUEST })
export class KeycloakService {
  constructor(
    @Inject(KEYCLOAK_INSTANCE) private keycloak: Keycloak,
    @Inject(KEYCLOAK_CONNECT_OPTIONS) private options: KeycloakConnectOptions,
  ) {}

  encodeFormData = (data: { [x: string]: string | number | boolean }) => {
    return Object.keys(data)
      .map(
        (key) => encodeURIComponent(key) + '=' + encodeURIComponent(data[key]),
      )
      .join('&');
  };

  async login(
    username: string,
    password: string,
    scope = 'openid profile ',
  ): Promise<unknown> {
    return await new Promise(async (resolve, reject) => {
      fetch(
        `${this.options.authServerUrl}/realms/${this.options.realm}/protocol/openid-connect/token`,
        {
          method: 'POST',
          body: this.encodeFormData({
            grant_type: 'password',
            client_id: this.options.clientId,
            client_secret: this.options.secret,
            scope: scope,
            username: username,
            password: password,
          }),
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        },
      )
        .then(async (res) => {
          const body = await res.json();

          if (res.status != 200) {
            console.log(res);
            throw new HttpException(body, res.status);
          }

          resolve(body)
          if (body['access_token']) {
            const grant = await this.keycloak.grantManager.createGrant({
              access_token: body['access_token'],
              refresh_token: body['refresh_token'],
            });

            resolve({
              access_token: grant.access_token['token'],
              refresh_token: grant.refresh_token['token'],
            });
          }
        })
        .catch((error) => reject(error));
    });
  }

  async logout(token): Promise<unknown> {
    return await new Promise(async (resolve, reject) => {
      fetch(
        `${this.options.authServerUrl}/realms/${this.options.realm}/protocol/openid-connect/logout`,
        {
          method: 'POST',
          body: this.encodeFormData({
            refresh_token: token,
            client_id: this.options.clientId,
            client_secret: this.options.secret,
          }),
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        },
      )
        .then(async (res) => {
          if (res.status != 204) {
            console.log(res);
            throw new HttpException('Invalid refresh token', res.status);
          }

          resolve();
        })
        .catch((error) => reject(error));
    });
  }

  async refresh(token: string): Promise<unknown> {
    return await new Promise(async (resolve, reject) => {
      fetch(
        `${this.options.authServerUrl}/realms/${this.options.realm}/protocol/openid-connect/token`,
        {
          method: 'POST',
          body: this.encodeFormData({
            grant_type: 'refresh_token',
            refresh_token: token,
            client_id: this.options.clientId,
            client_secret: this.options.secret,
          }),
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        },
      )
        .then(async (res) => {
          const body = await res.json();
          console.log(body);

          if (res.status != 200) {
            throw new HttpException(body, res.status);
          }

          resolve(body);
        })
        .catch((error) => reject(error));
    });
  }
}
